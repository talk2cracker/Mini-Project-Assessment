
# Node.js Real-Time Chat Application

## Description
A simple real-time chat application built using Node.js, Express, and Socket.io. This app demonstrates Node.js's capability to handle multiple concurrent connections using its non-blocking, event-driven architecture.

## Installation

```bash
npm install
```

## Usage

```bash
npm start
```

Then open [http://localhost:3000](http://localhost:3000) in your browser.

## Features
- Real-time messaging with Socket.io
- Handles multiple users concurrently
- Demonstrates Node.js scalability with non-blocking I/O
